function setup() {
  createCanvas(800, 800);
  
  
  background(170,255,0);
}

function draw() {
  
  
  
  background(random(170,255));
  
  noStroke()
  fill(random(100,255) , random(170 , 20))
  

      ellipse(mouseX-100 , mouseY-100 ,mouseY ,mouseX);
  
    fill(random(255) , random( 20))
  
  

  
}

